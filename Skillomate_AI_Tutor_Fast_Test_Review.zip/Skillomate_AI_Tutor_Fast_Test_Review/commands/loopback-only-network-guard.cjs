const net=require('node:net');
const hosts=new Set(['127.0.0.1','localhost','::1','[::1]']);
const connect=net.Socket.prototype.connect;
net.Socket.prototype.connect=function(...args){
 const a=Array.isArray(args[0])?args[0]:args;
 const first=a[0];
 const host=typeof first==='object'?first.host||first.hostname||'localhost':typeof a[1]==='string'?a[1]:'localhost';
 if(!hosts.has(host))throw Error('LOCAL_TEST: external network disabled');
 return connect.apply(this,args);
};
const fetch=globalThis.fetch;
globalThis.fetch=function(url,options){
 const u=new URL(typeof url==='string'||url instanceof URL?String(url):url.url);
 if(!hosts.has(u.hostname))throw Error('LOCAL_TEST: external fetch disabled');
 return fetch(url,{...options,redirect:'error'});
};
