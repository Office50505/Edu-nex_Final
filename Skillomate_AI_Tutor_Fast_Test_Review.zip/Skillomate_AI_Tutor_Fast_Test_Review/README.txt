PACKAGE GUIDE

EXECUTIVE_SUMMARY.txt: present status, scope, fixes, and evidence limits.
LAUNCH_BLOCKERS_AND_NEXT_ACTIONS.txt: pending live tests and all existing failures.
results/backend_test_inventory.csv and .json: all 1215 named test outcomes, parsed
  from the existing final log; 1201 PASS and 14 FAIL. Parsing did not execute tests.
results/backend_14_failures.txt: full existing failure assertions and stacks.
results/evaluator_test_inventory.json: all 173 named evaluator outcomes.
results/last_results.json: latest stored 30-case evaluation, with full responses.
results/prior_runs/: retained baseline and intermediate saved evaluations.
evaluation/: 30 cases, frozen hash, approved assets and unapproved live-test plan.
evidence/: full saved logs, metrics and sanitized retrieval/context/payload traces.
changes/: current relevant files, before snapshots, and this session's focused diff.
commands/: exact shell commands and the final-run local network guard.
MANIFEST.json: original and packaged SHA256 for copied evidence, with redaction status.
SHA256SUMS.txt: package-entry integrity hashes (the checksum file excludes itself).

The current source snapshots contain the pre-existing working-tree implementation
as well as this session's changes. The focused diff identifies this session's four
modified files; the two new focused regression files are included separately.
No repository history, dependencies, environment files, private runtime JSON,
bearer tokens, approval files, or real-user records are included.

Only synthetic local learner data were used in the evaluation. Emails and personal
filesystem paths are redacted even when they are test values. Secret-like literal
fixture values are also redacted. Redaction changes can make sanitized snapshots
unsuitable for direct execution; refer to the actual repository for reruns.
Logs were preserved with test names, outcomes, assertions, and source locations.
The existing last_results.json is copied byte-for-byte if it needs no redaction;
otherwise the manifest flags it as a sanitized copy. Original source files are unchanged.
Provider traces contain assembled payloads that were blocked, never real-provider successes.
